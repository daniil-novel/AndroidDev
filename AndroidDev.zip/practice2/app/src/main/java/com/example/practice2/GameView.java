package com.example.practice2;

public class GameView {
}
